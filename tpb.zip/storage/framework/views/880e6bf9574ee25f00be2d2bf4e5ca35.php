<?php $__env->startSection('content'); ?>
    <style>
        .image {
            width: 100%;
            height: 300px;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .animate-card {
            transform: translateY(50px);
            opacity: 0;
            transition: transform 0.5s cubic-bezier(0.25, 0.8, 0.25, 1), opacity 0.5s;
        }

        .animate-card.in-view {
            transform: translateY(0);
            opacity: 1;
        }
    </style>
    <div class="max-w-screen-xl p-4 mx-auto">
        <div class="space-y-5">
            <div class="mt-5 bg-white p-4 text-blue-500 rounded-xl text-2xl font-semibold text-center shadow-lg">
                Beranda
            </div>

            <div class="bg-white rounded-lg shadow-md p-4">
                <form action="<?php echo e(route('beranda')); ?>" method="get" class="flex">
                    <input type="text" name="search" id="search" placeholder="Ketik nama barang disini..."
                        class="focus:outline-none border rounded-l border-gray-300 px-3 py-2 w-64"
                        value="<?php echo e(request()->query('search')); ?>">
                    <button type="submit"
                        class="bg-blue-500 text-white border rounded-r border-blue-500 px-4 py-2 hover:bg-blue-600">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </form>


                <?php if($dataBarang->isEmpty()): ?>
                    <p class="mt-6 text-center text-gray-500">Tidak ada barang yang tersedia saat ini.</p>
                <?php else: ?>
                    <div id="card-section" class="grid grid-cols-1 gap-2 md:grid-cols-3 animate-card mt-4">
                        <?php $__currentLoopData = $dataBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('beranda.show', ['nama_barang' => $data->nama_barang])); ?>"
                                class="w-full p-3 border border-blue-300 rounded-lg shadow-lg">
                                <div class="flex justify-center w-full">
                                    <?php if($data->foto): ?>
                                        <img src="<?php echo e(asset('storage/' . $data->foto)); ?>" class="object-cover zoom-image"
                                            alt="<?php echo e($data->nama_barang); ?>" />
                                    <?php else: ?>
                                        <i class="fa-regular fa-image text-gray-400 text-6xl"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="mt-1">
                                    <span
                                        class="bg-blue-100 text-blue-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300">
                                        <?php echo e($data->kategori->nama_kategori ?? 'Tidak ada kategori'); ?>

                                    </span>
                                    <span
                                        class="bg-blue-100 text-blue-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300">
                                        Sisa <?php echo e($data->stock->stock ?? 'Tidak ada stock'); ?>

                                    </span>
                                </div>
                                <div class="mt-1">
                                    <p class="font-normal"><?php echo e(Str::limit($data->nama_barang, 50)); ?></p>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <div class="mt-4">
                    <?php echo e($dataBarang->links()); ?>

                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const cards = document.querySelectorAll('.animate-card');

            const observerOptions = {
                threshold: 0.1,
            };

            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('in-view');
                    } else {
                        entry.target.classList.remove('in-view');
                    }
                });
            }, observerOptions);

            cards.forEach(card => {
                observer.observe(card);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.ormawa.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tpb\resources\views/pages/ormawa/beranda/index.blade.php ENDPATH**/ ?>
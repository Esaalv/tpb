<?php $__env->startSection('content'); ?>
    <div class="p-4 sm:ml-64 mt-5">
        <?php if(session('success')): ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: '<?php echo e(session('success')); ?>',
                });
            </script>
        <?php endif; ?>

        <div class="space-y-4 rounded-lg mt-14">
            <div class="p-4 bg-white rounded-lg shadow-lg flex justify-between items-center">
                <p class="text-lg font-semibold">Mahasiswa</p>
                <button type="button" data-modal-target="add" data-modal-toggle="add"
                    class="px-2 py-1 bg-blue-200 rounded-lg cursor-pointer">
                    <i class="fa-solid fa-plus"></i>
                </button>
                <?php echo $__env->make('components.modal.tambah-pengguna-mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                <table class="w-full text-sm text-left rtl:text-right text-gray-500">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3">No</th>
                            <th scope="col" class="px-6 py-3">Nama Mahasiswa</th>
                            <th scope="col" class="px-6 py-3">Nim</th>
                            <th scope="col" class="px-6 py-3">Organisasi</th>
                            <th scope="col" class="px-6 py-3">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd:bg-white even:bg-gray-50 border-b border-gray-200">
                                <td class="px-6 py-4"><?php echo e($loop->iteration); ?></td>
                                <td class="px-6 py-4"><?php echo e($data->name); ?></td>
                                <td class="px-6 py-4"><?php echo e($data->nim); ?></td>
                                <td class="px-6 py-4"><?php echo e($data->organisasi); ?></td>
                                <td class="px-6 py-4 flex items-center gap-2">
                                    
                                    <button type="button" data-modal-target="edit<?php echo e($data->id); ?>"
                                        data-modal-toggle="edit<?php echo e($data->id); ?>"
                                        class="px-2 py-1 bg-yellow-500 rounded-lg text-white cursor-pointer">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </button>
                                    

                                    
                                    <?php echo $__env->make('components.modal.edit-pengguna-mahasiswa', ['data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    

                                    <form id="delete-form-<?php echo e($data->id); ?>"
                                        action="<?php echo e(route('mahasiswa.destroy', $data->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" onclick="confirmDelete(<?php echo e($data->id); ?>)"
                                            class="px-2 py-1 bg-red-500 rounded-lg text-white cursor-pointer">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            
        </div>
    </div>

    <script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data yang dihapus tidak dapat dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-form-' + id).submit();
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tpb\resources\views/pages/admin/pengguna/index.blade.php ENDPATH**/ ?>
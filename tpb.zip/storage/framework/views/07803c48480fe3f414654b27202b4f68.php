<?php $__env->startSection('content'); ?>
    <style>
        .image {
            width: 100%;
            height: 300px;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .animate-card {
            transform: translateY(50px);
            opacity: 0;
            transition: transform 0.5s cubic-bezier(0.25, 0.8, 0.25, 1), opacity 0.5s;
        }

        .animate-card.in-view {
            transform: translateY(0);
            opacity: 1;
        }
    </style>
    <div class="max-w-screen-xl p-4 mx-auto">
        <div class="space-y-5">
            <div class="mt-5 bg-white p-4 text-blue-500 rounded-xl text-2xl font-semibold text-center shadow-lg">
                Detail Barang
            </div>

            <div class="bg-white p-4 rounded-xl shadow-lg">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                    <div class="flex justify-center">
                        <?php if($barang->foto): ?>
                            <img src="<?php echo e(asset('storage/' . $barang->foto)); ?>"
                                class="image border border-blue-300 rounded-lg shadow-lg" alt="<?php echo e($barang->nama_barang); ?>" />
                        <?php else: ?>
                            <i class="fa-regular fa-image text-gray-400 text-6xl"></i>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div>
                            <p class="text-xl font-semibold"><?php echo e($barang->nama_barang); ?></p>
                        </div>
                        <div class="flex items-center justify-between">
                            <div>
                                <span
                                    class="bg-blue-100 text-blue-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-gray-700 dark:text-blue-400 border border-blue-400"><?php echo e($barang->kategori->nama_kategori); ?></span>
                                <span
                                    class="bg-blue-100 text-blue-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-gray-700 dark:text-blue-400 border border-blue-400"><?php echo e($barang->satuan->nama_satuan); ?></span>

                            </div>
                            <div>
                                <span
                                    class="bg-blue-100 text-blue-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-gray-700 dark:text-blue-400 border border-blue-400">Sisa
                                    <?php echo e($barang->stock->stock); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.ormawa.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tpb\resources\views/pages/ormawa/beranda/detail/index.blade.php ENDPATH**/ ?>
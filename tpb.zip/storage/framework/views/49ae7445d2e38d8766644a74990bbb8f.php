<?php $__env->startSection('content'); ?>
    <div class="max-w-screen-xl p-4 mx-auto">
        <div class="mt-5 bg-white p-4 text-blue-500 rounded-xl text-2xl font-semibold text-center shadow-lg">
            Informasi dan Layanan
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.ormawa.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\tpb\resources\views/pages/ormawa/informasi/index.blade.php ENDPATH**/ ?>
<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StockSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('stocks')->insert([
            [
                'stock' => 10,
                'barang_id' => 1, // Mikroskop
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stock' => 5,
                'barang_id' => 2, // Laptop
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stock' => 15,
                'barang_id' => 3, // Bola Basket
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stock' => 8,
                'barang_id' => 4, // Proyektor
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stock' => 20,
                'barang_id' => 5, // Whiteboard Marker
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stock' => 3,
                'barang_id' => 6, // Gitar Akustik
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stock' => 7,
                'barang_id' => 7, // Meja Lipat
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}

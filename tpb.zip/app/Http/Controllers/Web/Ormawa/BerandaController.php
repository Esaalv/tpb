<?php

namespace App\Http\Controllers\Web\Ormawa;

use App\Http\Controllers\Controller;
use App\Models\Barang;
use Illuminate\Http\Request;

class BerandaController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->query('search');

        $dataBarang = Barang::when($search, function ($query) use ($search) {
            return $query->where('nama_barang', 'like', '%' . $search . '%');
        })->simplePaginate(6);

        return view('pages.ormawa.beranda.index', compact('dataBarang', 'search'));
    }

    public function show($nama_barang)
    {
        $barang = Barang::where('nama_barang', $nama_barang)->first();

        return view('pages.ormawa.beranda.detail.index', compact('barang'));
    }
}

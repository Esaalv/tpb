@extends('pages.ormawa.index')
@section('content')
    <div class="max-w-screen-xl p-4 mx-auto">
        <div class="mt-5 bg-white p-4 text-blue-500 rounded-xl text-2xl font-semibold text-center shadow-lg">
            Informasi dan Layanan
        </div>
    </div>
@endsection
